# -*- coding: utf-8 -*-
# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.11.3
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

import numpy as np
from time import time
from PIL import Image
import torch
import torch.nn as nn
from IPython.display import clear_output
import matplotlib.pyplot as plt
from backbones import get_model
from privacy_pipeline import Pipeline
import torch.nn.functional as F
from tqdm.auto import tqdm
# +
DEVICE = torch.device("cuda")

# 获取 & 载入模型
net = get_model('r100',fp16=False).eval().to(DEVICE)
net.load_state_dict(torch.load('/private/data/backbone.pth'))

#这里的batch_size是干啥的: 用来在恢复的时候 一次sample几个出来
batch_size = 80
image_dim = 112

def tensorToImage(im):return ((im+1)/2).permute(1, 2, 0).cpu().detach().numpy()

from dataset import MXFaceDataset,DataLoaderX
# 载入数据集
train_set = MXFaceDataset('/private/data/ms1m-retinaface-t1',local_rank=0)
train_loader = DataLoaderX(local_rank=0,dataset=train_set,batch_size=1)
# -
# %%time
# test dataset time
l = []
with torch.no_grad():
    test = DataLoaderX(local_rank = 0,dataset = train_set, batch_size = 200)
    for X,y in tqdm(test):
        for i in range(4):
            xx=X[y==(torch.ones(y.shape[0]).cuda())*i]
            l.append(xx)
        break


# !ls save

for X in l:
    xx = X.sum(dim=0,keepdim=True)/X.shape[0]
    print(xx.shape)
    emb=F.normalize(net(xx))
    emb_center=torch.load('save/emb_average.pt')
    print((emb**2).sum(),(emb_center**2).sum())
    print((emb*emb_center).sum())
    # plt.imshow(tensorToImage(xx[0]))
    # plt.show()
    break

with torch.no_grad():
    for i in train_loader:
        l = i[0]
        break
    emb_target = net(l)
    print(emb_target,torch.norm(emb_target))
# plt.imshow(tensorToImage(l[0]))

pipeline = Pipeline(emb_target,
                    net,
                    DEVICE,
                    dim=image_dim,
                    batch_size=batch_size,
                    sym_part=1,
                    multistart=True,
                    gauss_amplitude=0.1,
                    color=False,
                    )

(emb_target**2).sum()

cosines_target = []
facenet_sims = []

with torch.no_grad():
    for i in range(15000):
        start = time()
        
        recovered_face, cos_target = pipeline()
        
        cosines_target.append(cos_target)
        
        
        if i % 10 == 0:
            clear_output(wait=True)
            recovered_face = np.transpose(recovered_face.cpu().detach().numpy(),(1,2,0))
            recovered_face = recovered_face - np.min(recovered_face)
            recovered_face = recovered_face / np.max(recovered_face)
            
            plt.figure(dpi=130)
            plt.imshow(recovered_face)
            plt.title(f"iterations {i*pipeline.batch_size}   cos_target={round(cos_target,3)}   norm={round(pipeline.norm,3)} best={(round(pipeline.best_value.item(),3))}")
            plt.show()
            
            plt.plot(cosines_target)
            plt.grid()
            plt.title("cos with a target embedding vs iters")
            plt.show()
# 继续除了 clamp以外, 还变了 gauss的产生方式, 这样可能出来有点奇怪么?


# +






























